<?php

require_once BRIDGE_CORE_SHORTCODES_PATH.'/pricing-calculator/pricing-calculator.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/pricing-calculator/pricing-calculator-functions.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/pricing-calculator/options-map/map.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/pricing-calculator/custom-styles/custom-styles.php';