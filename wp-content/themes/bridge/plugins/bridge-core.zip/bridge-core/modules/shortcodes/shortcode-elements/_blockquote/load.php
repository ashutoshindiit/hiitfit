<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_blockquote/blockquote.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_blockquote/custom-styles/custom-styles.php';
